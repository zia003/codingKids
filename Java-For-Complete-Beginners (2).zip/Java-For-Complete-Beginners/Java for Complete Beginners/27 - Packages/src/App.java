import ocean.Fish;
import ocean.plants.Seaweed;
 
public class App {
 
     
    public static void main(String[] args) {
        Fish fish = new Fish();
        Seaweed weed = new Seaweed();
    }
 
}