const caEmail='input[type=email]';
const caName='input[type=text]';
const caPhone='input[type=tel]';
const caPassword='input[type=password]';
const createAccountButton='.primary-button.large';


class createAccount{



static createAccountAndPurchase() {

    cy.get('input')
    cy.get(caEmail).type('Sridhar026@mailinator.com');
    cy.get(caName).eq(0).type('Sridhar');
    cy.get(caName).eq(1).type('Sundarrajan');
    cy.get(caPhone).type('8754752020');
    cy.get(caPassword).type('@1Iwanttobuy');
    cy.get(createAccountButton).click();

}
}export default createAccount;