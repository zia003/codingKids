const vehicleCardViewAll=".text-underscore-black-link";
const vehicleVinAll='.vin-status-container';
const vehicleVinAll2='.vin';
const searchSortByDD='.mat-select-value-text';
const searchSortByDDValue='.mat-option.mat-focus-indicator';



class smartPathSearchResult {

    static viewAccessories() {
        cy.get(vehicleCardViewAll)
            .should('contain.text', 'view all')
            .eq(0)
            .click();

        cy.get(vehicleCardViewAll)
            .should('contain.text', 'view less')
            .eq(0)
            .click();

    }

    static chooseVehicle() {
        cy.fixture('carTypeResponse.json').then((data) => {
            let targetVin = data['vehicleSummary'][0]['vin'];
            let carTypeData = data;
            cy.get(vehicleVinAll).should('have.length', carTypeData['pagination'].totalRecords);
            cy.get(vehicleVinAll2).should('have.length', carTypeData['pagination'].totalRecords);
            carTypeData['vehicleSummary'].sort((a : any, b : any) => (a.price.advertizedPrice > b.price.advertizedPrice ? 1 : -1));
            cy.get(searchSortByDD).click();
            cy.get(searchSortByDDValue).eq(1).click();
            cy.wait(5000);
            cy.get(`[id=${targetVin}]`).click();
        })



    }


}
export default smartPathSearchResult;