
import genericAction from '../Helper/helper';


//price filter locators

const minPriceInputField = "(//input[@class='filter-slider-input'])[1]";
const sliderMinValue = "span.ngx-slider-model-value";
const maxPriceInputField = "(//input[@class='filter-slider-input'])[2]";
const sliderMaxValue = "span.ngx-slider-model-high";
const listedVehiclePrice = "div.vehicle-info>div.ng-star-inserted div.value";
const defaultMinVal = "span.ngx-slider-span.ngx-slider-bubble.ngx-slider-model-value";
const defaultMaxVal = "span.ngx-slider-span.ngx-slider-bubble.ngx-slider-model-high";

const vehicleCardsWithPrice = "//div[@class='vehicle-card']//div[@class='label'][contains(text(),'starting')]";
const priceResetButton = "div.reset-button.ng-star-inserted";
const hybridVehicleTypeCheckBox="//span[@class='mat-checkbox-label']//span[contains(text(),'Hybrid')]"

//vehicle sorting locators
const aToZSortSelectedSort = "//mat-select[@role='listbox']//span[contains(text(),'Sort by: A to Z')]";

const SortByDD = "div.mat-select-value";
const revAlphabetDDOption = "#mat-option-1 > .mat-option-text > span";
const sortByPriceLtoH = "#mat-option-2 > .mat-option-text > span";
const firstVehiclePrice = "(//div[@class='vehicle-card']//div[@class='value'])[1]"
const sortByPriceHtoL = "#mat-option-3 > .mat-option-text > span"

//vehicle listing section 
const vehicleCards = "div.vehicle-card";
const listedvehicleNames = "div.vehicle-card div.vehicle-name";
const headingNewCarTab = "div.main-header-available";
const vehicleCardButton=".content-wrapper > .vehicle-actions >.ng-star-inserted"

//contact us locator
const contactForm = '.con-textfield';
const phoneNumber = '[id="tel"]';
const send = 'Send';
const returnToPage = 'Return to Page';
const contactUsFormInput='input[id=textInput]';





//variables
let newCarData : any;
let carTypes = ['Cars', 'Crossovers', 'SUVs', 'Trucks', 'Minivan', 'Hybrids'];
let responseData;
let count : number;
let targetCarName : any;
let seriesCode : any;


class smartPathLanding {
 static expectedMinValue:string;
 static expectedMaxValue:string;
 static minPriceFromList:string;
 static maxPriceFromList:string;
 static formattedMinValue:number;
 static formattedMaxValue:number;

 static minPriceFromListSorting: number;
 static maxPriceFromListSorting: number;
 static formattedfirstPrice: number;


 //=============mstsc-smartpath-landing-price-filter==================================================
 static setMinValue() {
   cy.get(defaultMinVal).then((minVal) => {
     let minValue = minVal.text();
     this.expectedMinValue = minValue;
   })
 }

 static setMaxValue() {
   cy.get(defaultMaxVal).then((maxVal) => {
     let maxValue = maxVal.text();
     this.expectedMaxValue = maxValue;
   })
 }



 static getdefaultMinVal() {
   return cy.get(defaultMinVal);
 }

 static getdefaultMaxVal() {
   return cy.get(defaultMaxVal);
 }

 static getSmartPathPageTitle() {
   return cy.title();
 }

 static selectNewVehicleTab() {
 }

 static getNewCarTabHeading(){
   return cy.get(headingNewCarTab)
 }

 static scrollIntoListedVehicle() {
   return cy.get(headingNewCarTab).scrollIntoView();
 }



 static enterValueInMinPriceInputField(minVal:string) {
   cy.xpath(minPriceInputField).clear();
   cy.xpath(minPriceInputField).type(minVal);
   cy.xpath(minPriceInputField).type('{enter}');
 }
 static enterValueInMinPriceInputField2() {
     cy.fixture('smartpathLanding.json').then((smartpathLanding) => {     
   cy.xpath(minPriceInputField).clear();
   cy.xpath(minPriceInputField).type(smartpathLanding.updatedMinPrice);
   cy.xpath(minPriceInputField).type('{enter}');
     })
 }

 static validateUpdatedMinValue(expectedupdatedMinValue:string) {
   cy.get(sliderMinValue).then((vehPrice) => {      
   let actualMinVal = genericAction.formatPrice(vehPrice.text());
   expect(actualMinVal).to.equal(expectedupdatedMinValue);
     })
 }

 static getSliderMinValue(){
 return  cy.xpath(sliderMinValue);
 }

 static enterValueInMaxPriceInputField(maxVal:string) {
   cy.xpath(maxPriceInputField).clear();
   cy.xpath(maxPriceInputField).type(maxVal);
   cy.xpath(maxPriceInputField).type('{enter}');

 }

 static validateUpdatedMaxValue(expectedUpdatedMaxValue:string) {
   cy.get(sliderMaxValue).then((vehPrice) => {      
     let actualMaxVal = genericAction.formatPrice(vehPrice.text());
     expect(actualMaxVal).to.equal(expectedUpdatedMaxValue);
       })
 
 }

 static validatePriceRangeListedVehicle(updatedRangeMinValue:number, updatedRangeMaxValue:number) {
   cy.get(listedVehiclePrice).then((vehPrice) => {
     let vehPrice1 = vehPrice.text().split('  ');
     for (let i = 0; i < vehPrice1.length; i++) {
       let num = vehPrice1[i];
       let rangeVal = genericAction.formatPrice(num);
       if (rangeVal < updatedRangeMinValue && rangeVal > updatedRangeMaxValue) {
         assert.fail();
       }
     }

   });
 }

 static formattedMinVal() {
   cy.get(defaultMinVal).then((minVal) => {
     let minValue = minVal.text();
    this.formattedMinValue = genericAction.formatPrice(minValue);
   })
 }



 static formattedMaxVal() {
   cy.get(defaultMaxVal).then((maxVal) => {
     let maxValue = maxVal.text();
     this.formattedMaxValue = genericAction.formatPrice(maxValue);
       })
 }


 static enterValueLessThanDefaultMinVal() {
   cy.get(defaultMinVal).then((minVal) => {
     let minValue = minVal.text();
     let rangeMinVal = genericAction.formatPrice(minValue);
     rangeMinVal=rangeMinVal - 1;
     cy.xpath(minPriceInputField).clear();
     cy.xpath(minPriceInputField).type(String(rangeMinVal));
     cy.xpath(minPriceInputField).type('{enter}');
   })
 }

 static enterValueGreaterThanDefaultMinVal() {
   cy.get(defaultMaxVal).then((maxVal) => {
     let maxValue = maxVal.text();
     let rangeMaxVal = genericAction.formatPrice(maxValue);
     rangeMaxVal=rangeMaxVal + 1;
     cy.xpath(maxPriceInputField).clear();
     cy.xpath(maxPriceInputField).type(String(rangeMaxVal));
     cy.xpath(maxPriceInputField).type('{enter}');
   })
 }

 static validateVehicleWithPrice() {
   let listingCount:number;
   let priceListingCount;
   cy.get(vehicleCards).then((listing) => {
     listingCount = Cypress.$(listing).length;
   })
   cy.xpath(vehicleCardsWithPrice).then((priceListing) => {
     priceListingCount = Cypress.$(priceListing).length;
     expect(listingCount).to.equal(priceListingCount);
   })

 }

 static clickResetButton() {
   cy.wait(2000);
   cy.get(priceResetButton).click();
   cy.wait(2000);
 }


 static sortVehicleListByPrice() {
   cy.get(listedVehiclePrice).then((vehPrice) => {
     var val3 = new Array();
     let vehPrice1 = vehPrice.text().split('  ');
     for (let i = 0; i < vehPrice1.length; i++) {
       let num = vehPrice1[i];      
       val3[i] =  genericAction.formatPrice(num);
     }
     val3.sort((a, b) => a - b);
     const minlistVal = val3[0];
     this.minPriceFromList = minlistVal;

     cy.log(this.minPriceFromList);

     val3.sort((a, b) => a - b);
     const maxlistVal = val3[vehPrice1.length - 1];
     this.maxPriceFromList = maxlistVal
     cy.log(this.maxPriceFromList);

  
   });
 }
 static clickNEnterOnPriceInputBox() {
   cy.xpath(minPriceInputField).click();
   cy.xpath(minPriceInputField).type('{enter}');
 }

 static selectVehicleTypeHybrid(){
   cy.xpath(hybridVehicleTypeCheckBox).click();
   cy.wait(2000);
 }

 static setDVehicleMinMaxPriceData() {
    cy.fixture('dealerData.json').then((dealerVehicleDetails:any) => {
        let  maxVal:number = dealerVehicleDetails.vehiclePrices.max;
        let  minVal:number = dealerVehicleDetails.vehiclePrices.min;
   cy.fixture("smartpathLanding.json").then((priceData)=>{
      priceData.setMinPrice=minVal;
      priceData.setMaxPrice=maxVal;
      priceData.updatedMinPrice=minVal+2000;
      priceData.updatedMaxPrice=maxVal-2000;
      cy.writeFile("../mstc/cypress/fixtures/smartpathLanding.json",JSON.stringify(priceData))
        });
        cy.wait(2000);
 
})
}

//================mstsc-smartpath-landing-vehicle-sorting=======================================================================

static getaToZSortSelectedSort() {
    return cy.xpath(aToZSortSelectedSort);
}

static getfirstVehiclePrice() {
    cy.xpath(firstVehiclePrice);
}


static formattedFirstPriceVal() {
    cy.xpath(firstVehiclePrice).then((minVal) => {
        let minValue = minVal.text();
        this.formattedfirstPrice = genericAction.formatPrice(minValue);
    })
}


static validateVehicleNameSortingAsc() {
    cy.get(listedvehicleNames)
        .then(vehicleName => {
            const unsortedVName = vehicleName.map((index, nameList) => Cypress.$(nameList).text()).get();
            const sortedVName = unsortedVName.slice().sort();
            expect(unsortedVName, 'Items are alphabetic sorted').to.deep.equal(sortedVName);
        });
}

static validateVehicleNameSortingDesc() {
    cy.get(listedvehicleNames)
        .then(vehicleName => {
            const unsortedVNameDesc = vehicleName.map((index, nameList) => Cypress.$(nameList).text()).get();
            const sortedVNameDesc = unsortedVNameDesc.slice().sort().reverse();
            expect(unsortedVNameDesc, 'Items are reverse sorted').to.deep.equal(sortedVNameDesc);
        });
}

static clickSortingDropDown() {
    cy.get(SortByDD).click();
}

static selectZToASorting() {
    cy.get(revAlphabetDDOption).click();
    cy.wait(1000);
}

static selectPriceAscSorting() {
    cy.get(sortByPriceLtoH).click();
    cy.wait(1000);
}

static selectPriceDescSorting() {
    cy.get(sortByPriceHtoL).click();
    cy.wait(1000);
}

static getLowestPrice() {

    cy.get(listedVehiclePrice).then((vehPrice) => {
        var val3 = new Array();
        let vehPrice1 = vehPrice.text().split('  ');
        for (let i = 0; i < vehPrice1.length; i++) {
            let num = vehPrice1[i];
            val3[i] = genericAction.formatPrice(num);
        }
        val3.sort((a, b) => a - b);
        const minlistVal = val3[0];
        this.minPriceFromListSorting = minlistVal;
    });
}

static getHighestPrice() {

    cy.get(listedVehiclePrice).then((vehPrice) => {
        var val3 = new Array();
        let vehPrice1 = vehPrice.text().split('  ');
        for (let i = 0; i < vehPrice1.length; i++) {
            let num = vehPrice1[i];
            val3[i] = genericAction.formatPrice(num);
        }
        val3.sort((a, b) => b - a);
        const maxlistVal = val3[0];
        this.maxPriceFromListSorting = maxlistVal
    });
}


//=========================mstc-smartpath-basic-checks===================================================
static getCarTypeCount() {
  cy.get(vehicleCards).then((totalCarType) => {
     expect(totalCarType.length).to.equal(newCarData.length);
  });

}


static getDataFromPublicAPI() {
  cy.log('inside getDataFromPublicAPI')
  cy.fixture('dealerData.json').then((dealerVehicleDetails:any) => {
    responseData = dealerVehicleDetails.configuration;
    newCarData = responseData;
    cy.log(newCarData);
     })
}

static getCarTypeDetails() {
  cy.get(listedvehicleNames).should('have.length', newCarData.length);
  cy.get(listedvehicleNames).then((carName) => {
      cy.log('Data From UI:' + carName.text());
  })
}

static clickAllTypesAndCheck() {
  for (let i = 0; i < carTypes.length; i++) {
      cy.contains(carTypes[i]).click();
      cy.wait(2000);
      cy.get(vehicleCards).then((totalCarType) => {
          cy.log(`Total ${carTypes[i]} Type :`, totalCarType.length)
      });
      cy.contains(carTypes[i]).click();
  }
}

//===============mstc-smartpath-contact-dealer==========================================

static vehicleAvailabilityStatus() {
  cy.get(headingNewCarTab).then(($element) => {
      const text = $element.text()
      cy.log('Text is:', text)
  })
}

static clickContactDealer() {

  // cy.contains(contactDealer).click()
  cy.fixture('dealerData.json').then((response) => {
      responseData = response;
      let targetIndex = 0;

      for (let i = 0; i < responseData['configuration'].length; i++) {
          if (newCarData[i]['count'] = 0) {
              count = newCarData[i]['count'];
              targetIndex = i;
              targetCarName = responseData['configuration'][i]['marketingSeries'];
              seriesCode = responseData['configuration'][i]['seriesCode'];
              break;
          }
      }
      cy.get(vehicleCardButton)
          .should('contain.text', 'Contact Dealer')
          .eq(targetIndex)
          .click();
   });

}

static fillContactForm() {
  cy.get(contactForm).should('have.length', 4);
  cy.get(contactUsFormInput).eq(0).type('Sridhar')
  cy.get(contactUsFormInput).eq(1).type('Sundarrajan')
  cy.get(contactUsFormInput).eq(2).type('sridhar026@gmail.com')
  cy.get(phoneNumber).click();
  cy.contains(send).click();
}

static returnToHomePage() {
  cy.contains(returnToPage).click();
}

//=======================mstc-smartpath-buy-available-vehicle====================

static clickToBuy() {

  cy.fixture('dealerData.json').then((response) => {
      responseData = response;
      let targetIndex = 0;

      for (let i = 0; i < responseData['configuration'].length; i++) {
          if (newCarData[i]['count'] > 0) {
              count = newCarData[i]['count'];
              targetIndex = i;
              targetCarName = responseData['configuration'][i]['marketingSeries'];
              seriesCode = responseData['configuration'][i]['seriesCode'];
              break;
          }
      }
      cy.get(vehicleCardButton)
          .should('contain.text', `${count} Available Vehicles`)
          .eq(targetIndex)
          .click();
  });

}

}
export default smartPathLanding;