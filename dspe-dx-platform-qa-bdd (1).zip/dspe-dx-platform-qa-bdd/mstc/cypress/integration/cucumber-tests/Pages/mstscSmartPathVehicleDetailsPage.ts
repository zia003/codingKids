const carouselContainer='.carousel-container'
const carouselNextCTA='.next-btn'
const carouselCloseCTA='.overlay-close'
const viewAllVehicleLink='.vehicle-info-item  >.vehicle-info-item >.description.view-btn >.text-underscore-black-link.view-details-btn'
const vehicleDetailCloseCTA='#vehicle-detail-close-button';
const purchaseOptions='.mat-tab-label-content';
const startPurchaseCTA='.primary-button.large';
const cashDownInputText='input[class="cash-down-input"]';
const annualMilageRadioOption='.mat-radio-label-content';
const chooseCrditScoreDD= '.mat-select-value';
const chooseCrditScoreDDValue= '.mat-option.mat-focus-indicator';
const paymentOptShowMoreCTA='.text-button.load-more-txt';
const paymentOptRadio='.mat-radio-button.radio-item.mat-accent';
const selectAccessoriesCTA='.accessories-summary-container >.select-accessories-border';
const selectAccessoriesCheckbox='.accessory-card-price-select >.accessory-checkbox';
const selectAccessoriesDoneCTA='.primary-button.large.right-align';





class vehicleDetails{

static openImageGallery() {
    cy.get(carouselContainer).click();
    for (let i = 0; i < 8; i++) {
        cy.get(carouselNextCTA).click();
        cy.wait(1000);
    }
    cy.get(carouselCloseCTA).click();
}

static viewAllVehicleDetails() {
    cy.get(viewAllVehicleLink).click();
    cy.wait(2000);
    cy.contains('Interior Features').click();
    cy.wait(1000);

}

static readExteriorFeatures() {
    cy.contains('Exterior Features').click();
    cy.wait(1000);
}

static readSafetyFeatures() {
    cy.contains('Safety Features').click();
    cy.wait(1000);
}

static readPackageAndAccessories() {
    cy.contains('Package & Accessories').click();
}

static closeVehicleDetails() {
    cy.get(vehicleDetailCloseCTA).click();
}


static clickFinanceOption() {
    cy.get(purchaseOptions)
        .should('contain.text', 'Finance')
        .eq(1)
        .click();

}

static clickCashOption() {
    cy.get(purchaseOptions)
        .should('contain.text', 'Cash')
        .eq(2)
        .click();

}

static startPurchasing() {
    cy.get(startPurchaseCTA)
        .should('contain.text', 'Start Purchase')
        .eq(0)
        .click();

}

//=============mstc-smartpath-payment-options================================================
static inputCashDownAmount() {
    cy.get(cashDownInputText).trigger('mousedown');
    cy.get(cashDownInputText).clear();
    cy.wait(2000);
    cy.get(cashDownInputText).type('5000');
    cy.get(annualMilageRadioOption).eq(0).click();
    // cy.wait(3000);
}

static chooseAnnualMileage() {
    cy.wait(3000);
    cy.get(annualMilageRadioOption).eq(2).click();
    cy.wait(2000);
}

static chooseCreditScore() {
    cy.get(chooseCrditScoreDD).eq(0).click();
    cy.get(chooseCrditScoreDDValue).eq(1).click();
}

static clickPaymentOptions() {
    cy.wait(3000);
    cy.get(paymentOptShowMoreCTA).click();
    cy.get(paymentOptRadio).eq(6).click();
}

// static clickFinanceOption() {
//     cy.get('.mat-tab-label-content').eq(1).click();
// }

// static clickCashOption() {
//     cy.get('.mat-tab-label-content').eq(2).click();
// }


static clickAccessories() {
    cy.wait(3000);
    cy.get(selectAccessoriesCTA).click();
}

static chooseAlloyWheelLocks() {
    cy.wait(3000);
    cy.get(selectAccessoriesCheckbox).eq(0).click();
}

static chooseFirstAidKit() {
    cy.wait(3000);
    cy.get(selectAccessoriesCheckbox).eq(1).click();
}

static chooseTabletHolder() {
    cy.wait(3000);
    cy.get(selectAccessoriesCheckbox).eq(2).click();
}

static clickDone() {
    cy.wait(3000);
    cy.get(selectAccessoriesDoneCTA).click();
}

// static startPurchasing() {

//     cy.get('.primary-button.large').eq(0)
//         .click();


//     // cy.wait(3000);
//     // cy.contains('Start Purchase').eq(0).click();
//     // cy.get('.price-details >.primary-button.large')
//     //     .should('contain.text', 'Start Purchase')
//     //     .eq(0)
//     //     .click();
// }


        }export default vehicleDetails;