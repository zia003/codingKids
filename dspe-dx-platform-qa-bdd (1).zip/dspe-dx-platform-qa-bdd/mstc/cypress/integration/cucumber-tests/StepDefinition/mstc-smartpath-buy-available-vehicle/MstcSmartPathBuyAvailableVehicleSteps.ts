import { expect} from 'chai';
import { Given,When,Then} from 'cypress-cucumber-preprocessor/steps';

import smartPathLanding  from '../../Pages/mstscSmartPathLandingPage';
import smartPathSearchResult  from '../../Pages/mstscSmartPathSearchResulPage';
import vehicleDetails  from '../../Pages/mstscSmartPathVehicleDetailsPage';
import createAccount  from '../../Pages/mstscSmartPathCreateAccountPage';
import genericAction from '../../Helper/helper';
const fs = require('fs');
// let responseData;
// let newCarData;
Cypress.on('uncaught:exception', (err, runnable) => {
    return false;
});



Given(/^The user details is invoked to buy available vehicle$/, function() {
    genericAction.setDealerData();
    smartPathLanding.getDataFromPublicAPI()
    genericAction.visitSmartPathPage();
});

Then(/^The user wants to buy the available vehicle$/, function() {
   smartPathLanding.clickToBuy();
});

Then(/^The user views the packages and accessories for the car$/, function() {
    smartPathSearchResult.viewAccessories()
});

Then(/^The user decided to know the estimated amount$/, function() {
    genericAction.setCarTypeResponse()
    smartPathSearchResult.chooseVehicle();
});

Then(/^The user checks the car images one by one$/, function() {
    vehicleDetails.openImageGallery();
});

Then(/^The user wants to know all vehicle details$/, function() {
  vehicleDetails.viewAllVehicleDetails();
});

Then(/^The user reads the exterior features$/, function() {
    vehicleDetails.readExteriorFeatures();
});

Then(/^The user reads the safety features$/, function() {
    vehicleDetails.readSafetyFeatures();
});

Then(/^The user reads the package & accessories$/, function() {
    vehicleDetails.readPackageAndAccessories();
});

Then(/^The user closes the vehicle details$/, function() {
    vehicleDetails.closeVehicleDetails();
});

Then(/^The user checks the Finance option$/, function() {
    vehicleDetails.clickFinanceOption();
});

Then(/^The user checks the cash option$/, function() {
    vehicleDetails.clickCashOption();
});

Then(/^The user decided to start the purchase$/, function() {
    vehicleDetails.startPurchasing();
});

Then(/^The user is asked to create an account to start the purchase$/, function() {
    createAccount.createAccountAndPurchase();
});