import { Given, When, Then, And } from "cypress-cucumber-preprocessor/steps";
import smartPathLanding  from '../../Pages/mstscSmartPathLandingPage';
import genericAction from '../../Helper/helper';




//Background: User is on smartpath landing page
Given(/^User launch the smartpath URL$/, () => {
  genericAction.visitSmartPathPage();
  cy.wait(2000);
})

And(/^land on smartpath landing page$/, () => {
  cy.fixture('smartpathLanding.json').then((smartpathLanding) => {
    genericAction.getPageTitle().should('include', smartpathLanding.landingTitle);
       })
});

And(/^is on new vehicle tabs$/, () => {
  smartPathLanding.scrollIntoListedVehicle();
});


// //=====================================================================================================================
// //Scenario: User should be displayed with listed vehicle sorted by name

When(/^user scroll to the listed Vehilcle on new vehicle list$/, function () {
  smartPathLanding.scrollIntoListedVehicle();
 
  });

  And(/^default selected sorting is from A to Z$/, function () {

    smartPathLanding.getaToZSortSelectedSort();
});

  Then(/^user should be displayed with listed vehicle sorted alphabetically.$/, function () {
    smartPathLanding.validateVehicleNameSortingAsc();
  });

//=====================================================================================================================
//Scenario: User should be displayed with listed vehicle sorted by name in reverse order when sorting selected is Z to A


 And(/^click on Sort by option$/, function () {
  smartPathLanding.clickSortingDropDown();
   });

  And(/^select Sort by:Z to A option$/, function () {
    smartPathLanding.selectZToASorting();
  });

  Then(/^user should be displayed with listed vehicle sorted alphabetically in reverse order.$/, function (callback) {
    smartPathLanding.validateVehicleNameSortingDesc();
  });

  
//=====================================================================================================================
//Scenario: User should be displayed with listed vehicle sorted by price from low to high when sorting selected in low to high

And(/^select Sort by:low to high option$/, function () {
  smartPathLanding.selectPriceAscSorting();
  smartPathLanding.getLowestPrice();
  smartPathLanding.formattedFirstPriceVal();
});

Then(/^user should be displayed with listed vehicle sorted price wise from low to high$/, function () {
 expect(smartPathLanding.formattedfirstPrice).to.eq(smartPathLanding.minPriceFromListSorting);
});

//=====================================================================================================================
//Scenario: User should be displayed with listed vehicle sorted by price from low to high when sorting selected in low to high

And(/^select Sort by:high to low option$/, function () {
  smartPathLanding.selectPriceDescSorting();
  smartPathLanding.getHighestPrice();
  smartPathLanding.formattedFirstPriceVal();
});

Then(/^user should be displayed with listed vehicle sorted price wise from high to low$/, function () {
  expect(smartPathLanding.formattedfirstPrice).to.eq(smartPathLanding.maxPriceFromListSorting);
});


