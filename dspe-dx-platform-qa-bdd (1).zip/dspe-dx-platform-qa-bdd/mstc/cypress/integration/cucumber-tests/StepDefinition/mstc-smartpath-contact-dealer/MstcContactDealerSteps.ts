import { Given, When, Then } from 'cypress-cucumber-preprocessor/steps';
//import MstcContactDealerPage from './MstcContactDealerPage';
import genericAction from '../../Helper/helper';
import smartPathLanding  from '../../Pages/mstscSmartPathLandingPage';
const fs = require('fs');


Cypress.on('uncaught:exception', (err, runnable) => {
    return false;
});

Given(/^The user details is invoked to contact the dealer$/, function() {
    genericAction.setDealerData();
    smartPathLanding.getDataFromPublicAPI()
    genericAction.visitSmartPathPage();
});

Then(/^The user clicks used car filter option and checks for car availability$/, function() {
    // MstcContactDealerPage.clickUsedFilter();
    // MstcContactDealerPage.vehicleAvailabilityStatus();
});

Then(/^The user clicks new car filter option and checks for car availability$/, function() {
    // MstcContactDealerPage.clickNewFilter();
    smartPathLanding.vehicleAvailabilityStatus()
});


Then(/^The user wants to contact dealer to buy a new car$/, function() {
    smartPathLanding.clickContactDealer();
});


Then(/^The user fills the contact details form and submit it$/, function() {
    smartPathLanding.fillContactForm();
});


Then(/^The user is returned to home page$/, function() {
    smartPathLanding.returnToHomePage();
});