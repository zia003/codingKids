

import { Given, When, Then, And } from "cypress-cucumber-preprocessor/steps";
import genericAction from '../../Helper/helper';
import smartPathLanding  from '../../Pages/mstscSmartPathLandingPage';

//Background: User is on smartpath landing page
Given(/^User launch the smartpath URL$/, () => {
  genericAction.visitSmartPathPage();
  cy.wait(2000);
})

And(/^land on smartpath landing page$/, () => {
  cy.fixture('smartpathLanding.json').then((smartpathLanding) => {
    genericAction.getPageTitle().should('include', smartpathLanding.landingTitle);
  })
});

And(/^is on new vehicle tab$/, () => {
  smartPathLanding.scrollIntoListedVehicle();

});

//========================================================================================================================

// Scenario: Values updated on input price box should be reflected on the slider.
When(/^user change the price value from the minimum value price input box$/, function () {
  genericAction.setDealerData();
  smartPathLanding.setDVehicleMinMaxPriceData()
  cy.fixture('smartpathLanding.json').then((smartpathLanding) => {
    const minimumValue = smartpathLanding.updatedMinPrice
    smartPathLanding.enterValueInMinPriceInputField(minimumValue);
  });
});

Then(/^amount in min slider should be updated accordingly$/, function () {
  cy.fixture('smartpathLanding.json').then((smpathdata) => {
    const updMinValue = smpathdata.updatedMinPrice;
    smartPathLanding.validateUpdatedMinValue(updMinValue)
  });
});


When(/^user change the price value from the maximum value price input box$/, function () {
  cy.fixture('smartpathLanding.json').then((smpathdata) => {
    smartPathLanding.enterValueInMaxPriceInputField(smpathdata.updatedMaxPrice);

  });
});

Then(/^amount in max slider should be updated accordingly$/, function () {
  cy.fixture('smartpathLanding.json').then((smpathdata) => {
    const updMaxValue = smpathdata.updatedMaxPrice;
    smartPathLanding.validateUpdatedMaxValue(updMaxValue);

  });
});


//====================================================================================================================
// Scenario: User able to view result as per price range entered in the price input box.
When(/^user set price range on the price input box$/, function (rangeValue) {
  cy.fixture('smartpathLanding.json').then((smpathdata) => {
    const updMinValue = smpathdata.updatedMinPrice;
    const updMaxValue = smpathdata.updatedMaxPrice;
    // const rangeMinValue=rangeValue.rawTable[1][0];
    // const rangeMaxValue=rangeValue.rawTable[1][1];
    smartPathLanding.enterValueInMinPriceInputField(updMinValue);
    smartPathLanding.enterValueInMaxPriceInputField(updMaxValue);
  });
});

Then(/^user should be displayed with list of vehicle with selected price range$/, () => {
  cy.fixture('smartpathLanding.json').then((smpathdata) => {
    const updMinValue = smpathdata.updatedMinPrice;
    const updMaxValue = smpathdata.updatedMaxPrice;
    smartPathLanding.validatePriceRangeListedVehicle(updMinValue, updMaxValue);

  })
})

//====================================================================================================================
// Scenario: User should not be able to change value less than the default min value from price input box
When(/^user enter value less than the default minimum set value$/, function () {
  cy.wait(5000);
  smartPathLanding.setMinValue();
  smartPathLanding.enterValueLessThanDefaultMinVal();
});

Then(/^min value in price input box should set to default minimum price value$/, function () {
  smartPathLanding.getdefaultMinVal().should('have.text', smartPathLanding.expectedMinValue);

});

And(/^min value in price slider should set to minimum price value$/, function () {
  smartPathLanding.getdefaultMinVal().should('have.text', smartPathLanding.expectedMinValue);
});

//====================================================================================================================
//Scenario: User should not be able to change value more than the default max value from price input box

When(/^user enter value more than the default maximum set value$/, function () {
  cy.wait(5000);
  smartPathLanding.setMaxValue();
  smartPathLanding.enterValueGreaterThanDefaultMinVal();
});

Then(/^max value in price input box should set to default maximum price value$/, function () {
  smartPathLanding.getdefaultMaxVal().should('have.text', smartPathLanding.expectedMaxValue);
});

And(/^max value in price slider should set to maximum price value$/, function () {
  smartPathLanding.getdefaultMaxVal().should('have.text', smartPathLanding.expectedMaxValue);
});


//====================================================================================================================
//Scenario: User should see details of vehicle with price details only on clicking on price slider or price input box

When(/^user click move the price slider$/, function () {
  cy.log('add steps')

});

When(/^user change the price in input box$/, function (rangeValue) {
  cy.fixture('smartpathLanding.json').then((smpathdata) => {
    const updMinValue = smpathdata.updatedMinPrice;
    // const rangeMinValue=rangeValue.rawTable[1][0];
    smartPathLanding.enterValueInMinPriceInputField(updMinValue);
    cy.wait(2000);

  });
});

Then(/^user should only be displayed with vehicle having price details$/, function () {
  smartPathLanding.validateVehicleWithPrice();
});


//========================================================================================================================
//  Scenario: User able to reset value on price input box after setting the value

When(/^user set the value on price input box$/, function (rangeValue) {
  cy.wait(5000);
  smartPathLanding.setMinValue();
  smartPathLanding.setMaxValue();
  cy.fixture('smartpathLanding.json').then((smpathdata) => {
    const updMinValue = smpathdata.updatedMinPrice;
    const updMaxValue = smpathdata.updatedMaxPrice;
    // const rangeMinValue=rangeValue.rawTable[1][0];
    // const rangeMaxValue=rangeValue.rawTable[1][1];

    smartPathLanding.enterValueInMinPriceInputField(updMinValue);
    smartPathLanding.enterValueInMaxPriceInputField(updMaxValue);
  });
});
And(/^click on reset button$/, function () {
  smartPathLanding.clickResetButton();
});
Then(/^default min and max value should be set$/, function () {
  smartPathLanding.getdefaultMinVal().should('have.text', smartPathLanding.expectedMinValue);
  smartPathLanding.getdefaultMaxVal().should('have.text', smartPathLanding.expectedMaxValue);
});


//========================================================================================================================
//   Scenario: User should be displayed with correct minimum and maximum price range on price slider and price input box
When(/^user get the minimum and maximum price of listed vehicle$/, function () {
  smartPathLanding.clickNEnterOnPriceInputBox();
  smartPathLanding.formattedMinVal();
  smartPathLanding.formattedMaxVal();
  smartPathLanding.sortVehicleListByPrice();
});

Then(/^same minimum and maximum value should be displayed on price slider$/, function () {
  expect(smartPathLanding.formattedMinValue).to.eq(smartPathLanding.minPriceFromList);
  expect(smartPathLanding.formattedMaxValue).to.eq(smartPathLanding.maxPriceFromList);
});
