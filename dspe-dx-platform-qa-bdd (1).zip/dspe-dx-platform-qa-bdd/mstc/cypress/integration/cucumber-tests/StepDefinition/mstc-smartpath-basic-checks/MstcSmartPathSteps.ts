//import { expect } from 'chai';
import { Given, When, Then } from 'cypress-cucumber-preprocessor/steps';
import genericAction from '../../Helper/helper';
import smartPathLanding  from '../../Pages/mstscSmartPathLandingPage';
//const fs = require('fs');

Cypress.on('uncaught:exception', (err, runnable) => {
    return false;
});

Given(/^The Public API$/, function() {
     genericAction.setDealerData();
    smartPathLanding.getDataFromPublicAPI()

});

Given(/^Get the Dealer Details$/, function() {
   // MstcSmartPathPage.getDataFromPublicAPI();
});

Given(/^The retail user to check the basic functionalities$/, function() {
    genericAction.visitSmartPathPage();
});

When(/^The user clicks the used filter option$/, function() {});

Then(/^The vehicle availbility status should be validated$/, function() {});

Then(/^The user clicks the new filter option$/, function(callback) {});

Then(/^The total count of car type should be validated$/, function() {
    smartPathLanding.getCarTypeCount();
    
});


Then(/^The available car type details should be displayed$/, function() {
  smartPathLanding.getCarTypeDetails();

});

Then(/^The user clicks all the car types and checks the availability$/, function() {
    smartPathLanding.clickAllTypesAndCheck()
});

Then(/^The user checks the availability of cars based on the price range$/, function() {
    // MstcSmartPathPage.filterByMaxPrice(30000);
});