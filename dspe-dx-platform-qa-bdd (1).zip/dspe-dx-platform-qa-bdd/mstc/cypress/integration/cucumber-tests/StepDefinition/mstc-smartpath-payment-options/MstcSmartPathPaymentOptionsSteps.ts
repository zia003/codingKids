import { expect} from 'chai';
import { Given, Then} from 'cypress-cucumber-preprocessor/steps';
import genericAction from '../../Helper/helper';
import vehicleDetails  from '../../Pages/mstscSmartPathVehicleDetailsPage';
import createAccount  from '../../Pages/mstscSmartPathCreateAccountPage';


Cypress.on('uncaught:exception', (err, runnable) => {
    return false;
});

Given(/^The User is on the payment page$/, function() {
    // MstcSmartPathPaymentOptionsPage.getDealerData();
    // MstcSmartPathPaymentOptionsPage.vistPaymentPage();

    genericAction.setDealerData();
    genericAction.setCarTypeResponse();
    genericAction.vistPaymentPage();
});

Then(/^The User Enters the Cash Down Amount$/, function() {
    vehicleDetails.inputCashDownAmount();
});

Then(/^Chooses the annual mileage$/, function() {
    vehicleDetails.chooseAnnualMileage();
});

Then(/^Chooses the credit score$/, function() {
    vehicleDetails.chooseCreditScore();
});

Then(/^Chooses the payment options$/, function() {
    vehicleDetails.clickPaymentOptions();
});


Then(/^The User clicks the Finance option to buy the vehicle$/, function() {
    vehicleDetails.clickFinanceOption();
});

Then(/^The User clicks the Cash option to buy the vehicle$/, function() {
    vehicleDetails.clickCashOption();
});

Then(/^Chooses the additional savings$/, function() {});

Then(/^Decided to personalize the accessories$/, function() {
    vehicleDetails.clickAccessories();
    vehicleDetails.chooseAlloyWheelLocks();
    vehicleDetails.chooseFirstAidKit();
    vehicleDetails.chooseTabletHolder();
    vehicleDetails.clickDone();
});

Then(/^Decided to protect the vehicle$/, function() {


});

Then(/^Starts Purchase by creating account$/, function() {
    vehicleDetails.startPurchasing();

});

Then(/^The user is asked to create an account to start the purchase$/, function() {
    createAccount.createAccountAndPurchase();
});