const dealerDataAPIurl = 'https://mobile-api.rti.qa.toyota.com/retail/configurator';
const carTypeAPIurl = `https://mobile-api.rti.qa.toyota.com/retail/inventory?`;

let dealerCode;
let vin : any;


class genericAction{

           //launch smart path landing page
        static visitSmartPathPage() {
            cy.fixture('dealerInput.json').then((dealerInput) => {
                let dealerCode = dealerInput.dealerCode;
                const url = `inventory?dealerCd=${dealerCode}`;
                cy.visit(Cypress.config().baseUrl + url, {
                    auth: {
                        username: dealerInput.dealerUserName,
                        password: dealerInput.dealerPassword,
                    },
                });
                cy.log('URL launched with authentication')
            });
        }

    //format price from UI in number format
    static formatPrice(val: string) {
        var replaComma = new RegExp(",", "g");
        let num = val.replace(replaComma, "")
        num = num.replace("$", "");
        return Number(num);
    }

    //return page title
    static getPageTitle(){
        return cy.title();
    }
 
    //set dealer data from dealer API in dealerData.json fixture file 
     static setDealerData() {
        cy.fixture('dealerInput.json').then((dealerData) => {
            cy.request({
                method: 'GET',
                url: dealerDataAPIurl,
                headers: {
                    authority: dealerData.authority,
                    origin: dealerData.origin
                },
                qs: {
                    brand: dealerData.brand,
                    region: dealerData.region,
                    dealerCode: dealerData.dealerCode
                }
            }).then((response:any) => {
              let  responseData = response.body;
              cy.writeFile('../mstc/cypress/fixtures/dealerData.json', responseData);
            });
        });

     }

     //set dealer vehicle type data as per seriesCode carTypeResponse.json fixture file 
     static setCarTypeResponse() {
        cy.fixture('dealerInput.json').then((dealerData) => {
           
            cy.request({
                method: 'GET',
                url: carTypeAPIurl,
                headers: {
                    origin: dealerData.origin
                },
                qs: {
                    brand: dealerData.brand,
                    region: dealerData.region,
                    "dealer[]": dealerData.dealerCode,
                    "seriesCodes[]": dealerData.seriesCode,
                    zipCode: dealerData.zipCode
                }
            }).then((response) => {
                cy.writeFile('../mstc/cypress/fixtures/carTypeResponse.json', response['body']);
            });
        });
    }

    static vistPaymentPage() {
        cy.fixture('dealerInput.json').then((dealerInput) => {   
            dealerCode = dealerInput.dealerCode;
            cy.fixture('carTypeResponse.json').then((vehicleDatas) => {
                let configurationData = vehicleDatas['vehicleSummary'];
                for (let i = 0; i < configurationData.length; i++) {
                    vin = configurationData[i]['vin'];
                    break;
                }
                const vehiclePurchaseUrl = `inventory/details?dealerCd=${dealerInput.dealerCode}&vin=${vin}&source=${dealerInput.source}&zipcode=${dealerInput.zipCode}`;
                cy.visit(Cypress.config().baseUrl + vehiclePurchaseUrl, {
                    auth: {
                        username: dealerInput.dealerUserName,
                        password: dealerInput.dealerPassword,
                    },
                });
            });
        });
    
    
    }
    
}
export default genericAction;