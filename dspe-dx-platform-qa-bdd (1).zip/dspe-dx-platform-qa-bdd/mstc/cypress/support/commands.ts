// declare namespace Cypress {
//     interface Chainable {
//        LaunchSiteWithAuth(): Chainable<Element>
//        getPageTitle(): Chainable<Element>
//        formatPrice(): Chainable<Element>
//     }
//   }

// Cypress.Commands.add('LaunchSiteWithAuth', () => {
//     cy.fixture('dealerInput.json').then((dealerInput) => {
//         let dealerCode = dealerInput.dealerCode;
//         const url = `inventory?dealerCd=${dealerCode}`;
//         cy.visit(Cypress.env('smartpathBaseUrl') + url, {
//             auth: {
//                 username: dealerInput.dealerUserName,
//                 password: dealerInput.dealerPassword,
//             },
//         })
//         cy.log('After Timeout')
//     });
// })

// Cypress.Commands.add('getPageTitle', () => {
//     return cy.title();
// })

