
const rimraf = require('rimraf')

const testResultsDir = './cypress/test-results/*'
const testResultsJsonDir = './cypress/cucumber-json/*'

rimraf(testResultsDir, () => {
  console.log('Deleted former test results under test-results');

})

rimraf(testResultsJsonDir, () => {
  console.log('Deleted former json file under cucumber-json')
})